docker container stop test_sshd
docker container rm test_sshd
